import React from 'react'

const Account = () => {
  return (
    <div className="container">
    <div className="  bg-white row shadow">
      <h2 className="border_color ms-md-2 my-3 pb-3">Account Setting</h2>

     
      
    </div>
  </div>
  )
}

export default Account