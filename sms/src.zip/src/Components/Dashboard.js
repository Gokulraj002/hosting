import React from "react";
import { NavLink } from "react-router-dom";
import {
  FaUsers,
  FaToggleOn,
  FaThLarge,
  FaMoneyBill,
  FaFilePdf,
  FaToggleOff
} from "react-icons/fa";

const Dashboard = () => {
  return (
    <>
      <div className="container">
        <div className="  bg-white row shadow">
          <h2 className="border_color ms-md-2 my-3 pb-3">Dashboard</h2>

          <div className="col-12 col-md-4 mb-4">
            <NavLink
              to="/"
              className="text-decoration-none "
            >
              <div className="mx-1 one shadow rounded text-center py-3">
                <FaUsers className="w-100 display-1 text-light " />
                <div className="text-white dash mt-1">
                  <p>Total Student : 8</p>
                  <p>MANAGE STUDENTS</p>
                </div>
              </div>
            </NavLink>
          </div>

          <div className="col-12 col-md-4 mb-4">
            <NavLink
              to="/Fees"
              className="text-decoration-none"
            >
              <div className="mx-1 bg-success shadow rounded text-center py-3">
                <FaMoneyBill className="w-100 display-1 text-light" />
                <div className="text-white dash mt-1">
                  <p>Total Earnings : rs.80965</p>
                  <p>Collect Fees</p>
                </div>
              </div>
            </NavLink>
          </div>

          <div className="col-12 col-md-4 mb-4">
            <NavLink
              to="/Report"
              className="text-decoration-none"
            >
              <div className="mx-1 bg-danger shadow rounded text-center py-3">
                <FaThLarge className="w-100 display-1 text-light" />
                <div className="text-white dash mt-1">
                  <p>Total Pending : RS-88921</p>
                  <p>Collect Fees</p>
                </div>
              </div>
            </NavLink>
          </div>

          <div className="col-12 col-md-4 mb-4">
            <NavLink
              to="/Student"
              className="text-decoration-none"
            >
              <div className="mx-1 four bg-opacity-75 shadow rounded text-center py-3">
                <FaToggleOn className="w-100 display-1 text-light" />
                <p className="text-white dash mt-1">Active Students : RS-88921</p>
              </div>
            </NavLink>
          </div>

          <div className="col-12 col-md-4 mb-4">
            <NavLink
              to="/Report"
              className="text-decoration-none"
            >
              <div className="mx-1 bg-dark bg-opacity-75 shadow rounded text-center py-3">
                <FaFilePdf className="w-100 display-1 text-light" />
                <p className="text-white dash mt-1">View Reports</p>
              </div>
            </NavLink>
          </div>

          <div className="col-12 col-md-4 mb-4">
            <NavLink
              to="/In-Active"
              className="text-decoration-none"
            >
              <div className="mx-1 six shadow rounded text-center py-3">
                <FaToggleOff className="w-100 display-1 text-light" />
                <p className="text-white dash mt-1">In-Active Students : 2</p>
              </div>
            </NavLink>
          </div>
        </div>
      </div>
    </>
  );
};

export default Dashboard;
